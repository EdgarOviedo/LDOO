package FactoryMethod;

/**
 *
 * @author Edgar Alexis Cerda Oviedo  1793849
 */
public class Bombero implements Trabajador {

    @Override
    public void nombre() {
        System.out.println("Nombre: Juan");
    }

    @Override
    public void trabajo() {
        System.out.println("Trabajo: Bombero");
    }

    @Override
    public void edad() {
        System.out.println("Edad: 42 años");
    }

    @Override
    public void saludar() {
        System.out.println("Hola, mi nombre es Juan y soy Bombero\n");
    }

}
