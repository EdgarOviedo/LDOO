package FactoryMethod;

/**
 *
 * @author Edgar Alexis Cerda Oviedo  1793849
 */
public class Taxista implements Trabajador{

    @Override
    public void nombre() {
        System.out.println("Nombre: David");
    }

    @Override
    public void trabajo() {
        System.out.println("Trabajo: Taxista");
    }

    @Override
    public void edad() {
        System.out.println("Edad: 50 años");
    }

    @Override
    public void saludar() {
        System.out.println("Hola, me llamo David y soy taxista\n");
    }

}
