package FactoryMethod;

/**
 *
 * @author Edgar Alexis Cerda Oviedo  1793849
 */
public class FactoryApp {
    public static void main(String[] args) {
        TrabajadorFactory trabajadorFactory = new TrabajadorFactory();
        
        Trabajador trabajador1 = trabajadorFactory.getTrabajador("Bombero");
        //Metodos de la clase Bombero:
        trabajador1.nombre();
        trabajador1.trabajo();
        trabajador1.edad();
        trabajador1.saludar();
        
        
        Trabajador trabajador2 = trabajadorFactory.getTrabajador("Policia");
         //Metodos de la clase Policia:
         trabajador2.nombre();
         trabajador2.trabajo();
         trabajador2.edad();
         trabajador2.saludar();

         
         Trabajador trabajador3 = trabajadorFactory.getTrabajador("Taxista");
         //Metodos de la clase Taxista:
         trabajador3.nombre();
         trabajador3.trabajo();
         trabajador3.edad();
         trabajador3.saludar();
   }
}
