package FactoryMethod;

/**
 *
 * @author Edgar Alexis Cerda Oviedo  1793849
 */
public class TrabajadorFactory {
    public Trabajador getTrabajador(String trabajador){
        if(trabajador == null){
            return null;
            
        }else if(trabajador.equalsIgnoreCase("Bombero")){
            return new Bombero();
            
        }else if(trabajador.equalsIgnoreCase("Policia")){
            return new Policia();
            
        } else if(trabajador.equalsIgnoreCase("Taxista")){
            return new Taxista();
        }
        
      return null;
   }
}
