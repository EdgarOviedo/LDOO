package FactoryMethod;

/**
 *
 * @author Edgar Alexis Cerda Oviedo  1793849
 */
public class Policia implements Trabajador {

    @Override
    public void nombre() {
        System.out.println("Nombre: Roberto");
    }

    @Override
    public void trabajo() {
        System.out.println("Trabajo: Policia");
    }

    @Override
    public void edad() {
        System.out.println("Edad: 36 años");
    }

    @Override
    public void saludar() {
        System.out.println("Hola, mi nombre es Roberto y soy policia\n");
    }

}
