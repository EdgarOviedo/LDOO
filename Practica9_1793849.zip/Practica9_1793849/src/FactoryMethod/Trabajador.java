package FactoryMethod;

/**
 *
 * @author Edgar Alexis Cerda Oviedo  1793849
 */
public interface Trabajador {
    public void nombre();
    public void trabajo();
    public void edad();
    public void saludar();
}
